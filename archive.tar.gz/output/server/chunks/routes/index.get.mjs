import { e as eventHandler } from '../../index.mjs';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';

const index_get = eventHandler(() => {
  return `${Bun.nanoseconds() / 1e9} seconds`;
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
